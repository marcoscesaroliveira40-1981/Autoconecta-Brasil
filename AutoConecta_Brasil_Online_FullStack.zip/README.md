# AutoConecta Brasil — versão online (starter full-stack)

Este projeto é uma base pronta para publicar com **Next.js + Supabase**:
- catálogo público de veículos;
- autenticação de administrador (Supabase Auth);
- cadastro/edição/remoção de carros no painel;
- controle de comissão por veículo (valor combinado, status, recebida);
- segurança por RLS: visitantes veem apenas anúncios publicados; administrador autenticado gerencia tudo.

## O que ainda precisa ser feito para ficar público
Você precisa criar as contas/serviços e informar as chaves:
1. Crie um projeto em https://supabase.com
2. No SQL Editor, execute `supabase/schema.sql`.
3. Em Authentication → Users, crie o usuário administrador (seu e-mail e senha).
4. Copie URL e anon key em `web/.env.local` (modelo em `.env.example`).
5. Instale Node.js 20+; no terminal, entre em `web`, rode `npm install` e `npm run dev`.
6. Para publicar, importe a pasta `web` no Vercel e configure as mesmas variáveis de ambiente.
7. No Supabase, mantenha confirmação de e-mail e senha forte; não compartilhe a service-role key.

## Estrutura
- `web/`: aplicação Next.js.
- `supabase/schema.sql`: banco, políticas e funções de segurança.
- `web/.env.example`: variáveis necessárias.

## Importante
Este pacote é código-fonte e não está hospedado nem conectado a um banco real ainda. Não há URL pública ativa.
