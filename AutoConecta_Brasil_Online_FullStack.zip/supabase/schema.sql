-- AutoConecta Brasil | Supabase PostgreSQL
create extension if not exists pgcrypto;

create table if not exists public.admins (
  user_id uuid primary key references auth.users(id) on delete cascade,
  created_at timestamptz not null default now()
);
alter table public.admins enable row level security;
create policy "admins can read own membership" on public.admins
  for select to authenticated using (user_id = auth.uid());

create or replace function public.is_admin()
returns boolean language sql stable security definer
set search_path = public
as $$ select exists(select 1 from public.admins where user_id = auth.uid()) $$;
revoke all on function public.is_admin() from public;
grant execute on function public.is_admin() to authenticated;

create table if not exists public.vehicles (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  make text not null,
  model text not null,
  year integer not null check (year between 1900 and 2100),
  price numeric(12,2) not null check (price >= 0),
  km integer not null default 0 check (km >= 0),
  city text not null,
  state char(2) not null,
  description text default '',
  photo_url text default '',
  seller_name text not null,
  seller_phone text not null,
  status text not null default 'draft' check (status in ('draft','published','sold','archived')),
  commission_amount numeric(12,2) not null default 0 check (commission_amount >= 0),
  commission_status text not null default 'pending' check (commission_status in ('pending','agreed','received')),
  commission_notes text default '',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists vehicles_status_created_idx on public.vehicles(status, created_at desc);
alter table public.vehicles enable row level security;

create policy "public sees published vehicles" on public.vehicles
  for select to anon, authenticated using (status = 'published' or public.is_admin());
create policy "admin inserts vehicles" on public.vehicles
  for insert to authenticated with check (public.is_admin());
create policy "admin updates vehicles" on public.vehicles
  for update to authenticated using (public.is_admin()) with check (public.is_admin());
create policy "admin deletes vehicles" on public.vehicles
  for delete to authenticated using (public.is_admin());

-- Depois de criar o usuário em Authentication > Users, execute:
-- insert into public.admins(user_id) values ('UUID_DO_USUARIO_ADMIN');
