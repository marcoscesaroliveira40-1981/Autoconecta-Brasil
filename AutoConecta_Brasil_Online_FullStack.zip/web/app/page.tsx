'use client';
import { useEffect,useState } from 'react';
import Link from 'next/link';
import { supabase } from '../lib/supabase';
type Car={id:string,title:string,make:string,model:string,year:number,price:number,km:number,city:string,state:string,description:string,photo_url:string,seller_name:string,seller_phone:string};
const money=(n:number)=>n.toLocaleString('pt-BR',{style:'currency',currency:'BRL'});
export default function Home(){
 const [cars,setCars]=useState<Car[]>([]); const [q,setQ]=useState(''); const [loading,setLoading]=useState(true);
 useEffect(()=>{supabase.from('vehicles').select('*').eq('status','published').order('created_at',{ascending:false}).then(({data})=>{setCars((data||[]) as Car[]);setLoading(false)})},[]);
 const filtered=cars.filter(c=>(c.title+' '+c.make+' '+c.model+' '+c.city).toLowerCase().includes(q.toLowerCase()));
 const wa=process.env.NEXT_PUBLIC_WHATSAPP||'5543984589664';
 return <main className="wrap"><section className="hero"><h1>AutoConecta Brasil</h1><p>Seu próximo carro começa aqui. Conectamos compradores e vendedores.</p><Link className="btn" href="/admin">Área administrativa</Link></section>
 <div className="bar"><h2>Veículos anunciados</h2><input placeholder="Buscar marca, modelo ou cidade…" value={q} onChange={e=>setQ(e.target.value)} style={{padding:12,borderRadius:9,border:'1px solid #cbd5e1',minWidth:260}}/></div>
 {loading?<p>Carregando anúncios…</p>:filtered.length===0?<p>Nenhum veículo publicado ainda. Volte em breve!</p>:<div className="grid">{filtered.map(c=><article className="card" key={c.id}><div className="photo">{c.photo_url?<img src={c.photo_url} alt={c.title}/>:<span>Foto do veículo</span>}</div><div className="pad"><h3>{c.title}</h3><p className="muted">{c.year} · {c.km.toLocaleString('pt-BR')} km · {c.city}/{c.state}</p><div className="price">{money(Number(c.price))}</div><p>{c.description}</p><a className="btn" href={`https://wa.me/${wa}?text=${encodeURIComponent('Olá! Tenho interesse no veículo '+c.title)}`} target="_blank">Tenho interesse</a></div></article>)}</div>}
 <footer className="muted" style={{padding:'35px 0'}}>AutoConecta Brasil · Intermediação de contatos. Negociação e pagamento diretamente entre as partes.</footer></main>
}
